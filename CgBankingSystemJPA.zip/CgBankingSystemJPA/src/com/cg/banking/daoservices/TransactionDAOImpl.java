package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public class TransactionDAOImpl implements TransactionDAO {
	
	private	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Transaction save(Account accountNo, Transaction transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		transaction.setAccount(accountNo);
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}

	@Override
	public boolean update(Account accountNo, Transaction transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		transaction.setAccount(accountNo);
		entityManager.getTransaction().begin();
		entityManager.merge(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Transaction findOne(Account accounntNo, int transactionId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Transaction.class, transactionId);
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		return(List<Transaction>)entityManagerFactory.createEntityManager().createQuery("from Transaction t",Transaction.class).getResultList();
	}


	/*
	 * @Override public Transaction save(long accountNo, Transaction transaction) {
	 * 
	 * try {
	 * 
	 * con.setAutoCommit(false);
	 * 
	 * PreparedStatement pstmt1 = con.
	 * prepareStatement("insert into Transaction(transactionId,amount,transactionType)values(Transaction_ID_SEQ.NEXTVAL,?,?)"
	 * ); pstmt1.setFloat(1, transaction.getAmount()); pstmt1.setString(2,
	 * transaction.getTransactionType());
	 * 
	 * pstmt1.executeUpdate();
	 * 
	 * PreparedStatement pstmt2 =
	 * con.prepareStatement("select max(transactionId) from Transactions");
	 * ResultSet rs = pstmt2.executeQuery(); rs.next(); int transactionId =
	 * rs.getInt(1);
	 * 
	 * transaction.setTransactionId(transactionId);
	 * 
	 * con.commit(); }catch(SQLException e) { e.printStackTrace(); try {
	 * con.rollback(); }catch(SQLException e1) { e1.printStackTrace(); } }
	 * 
	 * return transaction; }
	 * 
	 * @Override public boolean update(long accountNo, Transaction transaction) { //
	 * TODO Auto-generated method stub return false; }
	 * 
	 * @Override public Transaction findOne(long accounntNo, int transactionId) { //
	 * TODO Auto-generated method stub return null; }
	 * 
	 * @Override public List<Transaction> findAll(long accountNo) { // TODO
	 * Auto-generated method stub return null; }
	 */

	/*
	 * @Override public Transaction save(long accountNo, Transaction transaction) {
	 * // TODO Auto-generated method stub
	 * transaction.setTransactionId(BankingDBUtil.generateTRANSACTION_ID());
	 * BankingDBUtil.customerDetails.get(accountNo).getTransactions().put(
	 * transaction.getTransactionId(), transaction); return transaction; }
	 * 
	 * @Override public boolean update(long accountNo, Transaction transaction) { //
	 * TODO Auto-generated method stub return false; }
	 * 
	 * @Override public Transaction findOne(long accountNo, int transactionId) { //
	 * TODO Auto-generated method stub return
	 * BankingDBUtil.customerDetails.get(accountNo).getTransactions().get(
	 * transactionId); }
	 * 
	 * @Override public List<Transaction> findAll(long accountNo) { // TODO
	 * Auto-generated method stub return new
	 * ArrayList<Transaction>(BankingDBUtil.customerDetails.get(accountNo).
	 * getTransactions().values()); }
	 */
	
	

}
