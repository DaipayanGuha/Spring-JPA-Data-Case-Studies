package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	AccountDAOImpl custData1 = new AccountDAOImpl();
	TransactionDAOImpl transacData = new TransactionDAOImpl();

	private final static float minBalance = 1000;
	private final static int maxInvalidPinAttempts = 3;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAccountTypeException, InvalidAmountException, BankingServicesDownException {
		if (initBalance <= minBalance)
			throw new InvalidAmountException();

		Account cust = custData1.save(new Account(accountType, initBalance));
		transacData.save(cust, new Transaction(initBalance, "Deposit"));
		return cust;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = getAccountDetails(accountNo);
		if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			customers.setAccountBalance(customers.getAccountBalance() + amount);
		this.custData1.update(customers);
		transacData.save(customers, new Transaction(amount, "Deposit"));
		return customers.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = getAccountDetails(accountNo);
		if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Account Blocked!");
		else if (customers.getPinNumber() != pinNumber) {
			customers.incrPinAttempts();
			System.out.println("Invalid Pin, Try again");
			if (customers.getPinAttempts() == maxInvalidPinAttempts) {
					customers.setAccountStatus("Blocked");
					throw new AccountBlockedException();
				}
			throw new InvalidPinNumberException();
		}
		else if(customers.getPinAttempts() > 0 && !(customers.getAccountStatus().equalsIgnoreCase("Blocked")))
			customers.resetPinAttempts();
		else if (customers.getAccountBalance() - amount <= minBalance)
			throw new InsufficientAmountException();
		else
			customers.setAccountBalance(customers.getAccountBalance() - amount);
		this.custData1.update(customers);
		transacData.save(customers, new Transaction(amount, "Withdraw"));
		return customers.getAccountBalance();

	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException, InvalidPinNumberException {

		Account customerTo = getAccountDetails(accountNoTo);
		Account customerFrom = getAccountDetails(accountNoFrom);
		if (customerFrom.getAccountBalance() - transferAmount <= minBalance)
			throw new InsufficientAmountException();
		else if (customerFrom.getPinNumber() != pinNumber)
			throw new InvalidPinNumberException();
		else {
			this.custData1.update(customerTo);
			this.custData1.update(customerFrom);
			transacData.save(customerFrom,new Transaction(transferAmount,"Withdraw"));
			transacData.save(customerTo,new Transaction(transferAmount,"Deposit"));
			withdrawAmount(customerFrom.getAccountNo(), transferAmount, customerFrom.getPinNumber());
			depositAmount(customerTo.getAccountNo(), transferAmount);
		}

		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account customers = null;
		customers = custData1.findOne(accountNo);
		if (customers == null)
			throw new AccountNotFoundException();

		return customers;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> customers = custData1.findAll();
		return customers;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return transacData.findAll(accountNo);
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers = custData1.findOne(accountNo);
		if (customers == null)
			throw new AccountNotFoundException();
		else if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		return customers.getAccountStatus();
	}

}
