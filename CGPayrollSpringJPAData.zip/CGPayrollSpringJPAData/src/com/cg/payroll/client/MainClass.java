package com.cg.payroll.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
//import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//PayrollServices services = new PayrollServicesImpl();
		ApplicationContext context = new ClassPathXmlApplicationContext("payrollBeans.xml");
		PayrollServices payrollServices = (PayrollServices) context.getBean("payrollServices");
		
		  int associateId1 = payrollServices.acceptAssociateDetails("Daipayan", "Guha","dguha@gmail.com", "JAVAFSDev", "Analyst", "ADB123", 1100, 22000, 100,1000,87654321, "CITI", "CITI98765");
		  int associateId2=payrollServices.acceptAssociateDetails("Tirtharaj", "Sur", "tsur@gmail.com","JAVAFSDev", "Analyst", "NA", 1200, 12000, 100, 1400, 12345678, "CITI","CITI54321");
		  System.out.println("Associate ID1 : " + associateId1);
		  System.out.println("Associate ID2 :"+ associateId2);
		  
		  Associate associate = null;
		  try { 
			  associate =payrollServices.getAssociateDetails(associateId1);
		  System.out.println("Details Found of associate Id :"+associateId1);
		  System.out.println("Monthly Gross Salary :"+payrollServices.calculateGrossSalary(associateId1));
		  System.out.println("Annual Net Salary : "+payrollServices.calculateNetSalary(associateId1)); }
		  catch(AssociateDetailsNotFoundException e) {
		  e.printStackTrace(); 
		  }
		  
		  try { 
			  associate = payrollServices.getAssociateDetails(associateId2);
		  System.out.println("Details Found of associate Id :"+associateId2);
		  System.out.println("Monthly Gross Salary :"+payrollServices.calculateGrossSalary(associateId2));
		  System.out.println("Annual Net Salary : "+payrollServices.calculateNetSalary(associateId2)); 
		  }catch(AssociateDetailsNotFoundException e) {
		  e.printStackTrace(); 
		  }
		  
		  List<Associate> a1 = payrollServices.getAllAssociateDetails(); for(Associate
		  associate2 : a1) System.out.println(associate2);
		 
		
		}
	}
