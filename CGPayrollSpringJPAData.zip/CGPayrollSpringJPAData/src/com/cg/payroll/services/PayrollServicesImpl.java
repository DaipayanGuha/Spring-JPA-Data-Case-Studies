package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

@Component("payrollServices")
public class PayrollServicesImpl  implements PayrollServices{
	
	//private AssociateDAO associateDao = new AssociateDAOImpl();
	@Autowired
	private AssociateDAO associateDAO;
	/*
	public PayrollServicesImpl() {
		associateDAO = new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDao) {
		super();
		this.associateDAO = associateDao;
	}*/

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		// TODO Auto-generated method stub
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
				new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		associate = associateDAO.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		// TODO Auto-generated method stub
		Associate associate = getAssociateDetails(associateId);
		
		//return 12*calculateGrossSalary(associateId) + associate.getSalary().getCompanyPf() + associate.getSalary().getEpf();
		associate.getSalary().setNetSalaray((int)(12*calculateGrossSalary(associateId)+ associate.getSalary().getCompanyPf()+ associate.getSalary().getEpf()));
		return associate.getSalary().getNetSalaray();
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		return associateDAO.findById(associateId).orElseThrow(()-> new AssociateDetailsNotFoundException("Associate Details not found for : " + associateId));
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		// TODO Auto-generated method stub

	
		return associateDAO.findAll();
	}
	//GrossSalary on monthly basis
	@Override
	public double calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		// TODO Auto-generated method stub
		Associate associate = getAssociateDetails(associateId);
		return associate.getSalary().getBasicSalary()+.3*associate.getSalary().getBasicSalary()*2+ .25*associate.getSalary().getBasicSalary() + .2*associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
		
	}
	
}
