package com.cg.banking.client;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		
		  long accNo, accNoFrom, accNoTo; int pinNo; float amt; int ch;
		 
		BankingServices bankingServices = new BankingServicesImpl();
		Account customer1 = null;
		Account customer2 = null;
		try {
			customer1 = bankingServices.openAccount("Savings", 2000);
			customer1.setAccountStatus("Active");
		} catch (InvalidAccountTypeException | InvalidAmountException | BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		try {
			customer2 = bankingServices.openAccount("Current", 3000);
			customer2.setAccountStatus("Active");
		} catch (InvalidAccountTypeException | InvalidAmountException | BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		 * System.out.println("Account Details :" + customer1);
		 * System.out.println("Account Details :" + customer2);
		 */
		
		System.out.println("Account Details :" + customer1.getAccountNo());
		System.out.println("Account Details :" + customer2.getAccountNo());
		 
		 try {
			 System.out.println("Account Details of :" + customer1.getAccountNo() + " " + bankingServices.getAccountDetails(customer1.getAccountNo()));
			System.out.println("Account Details of :" + customer2.getAccountNo() + " " + bankingServices.getAccountDetails(customer2.getAccountNo()));
			
			
		 }catch(AccountNotFoundException | BankingServicesDownException e) {
			 e.printStackTrace();
		 }
		 
		 System.out.println("All Acount Details :");
		 try {
			 List<Account> a1 = bankingServices.getAllAccountDetails();
			 for(Account account : a1)
				 System.out.println(account);
			 
		 }catch(BankingServicesDownException e) {
			 e.printStackTrace();
		 }

		
		  Scanner sc = new Scanner(System.in); 
		  System.out.println(); 
			while (true) {
				
				System.out.println("Menu :\n1.Withdrawl\n 2.Deposit\n 3.Fund Transfer\n 4.Exit\nEnter choice :");
				ch = sc.nextInt();
				switch(ch) {
				case 1:
					
					System.out.println("*********WITHDRAWL*********");
					System.out.println("Enter Account No:");
					accNo = sc.nextLong();
					System.out.println("Enter Pin No.");
					pinNo = sc.nextInt();
					System.out.println("Enter amount to withdraw");
					amt = sc.nextFloat();
					try {
						System.out.println(bankingServices.withdrawAmount(accNo, amt, pinNo));
						System.out.println("Account Details after withdrawl:" + bankingServices.getAccountDetails(accNo));
					} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
						e.printStackTrace();
					}
					System.out.println();
					break;
				case 2:
					System.out.println("*********DEPOSIT*********");
					System.out.println("Enter Account No:");
					accNo = sc.nextLong();
					System.out.println("Enter amount to deposit");
					amt = sc.nextFloat();
					try {
						System.out.println(bankingServices.depositAmount(accNo, amt));
						System.out.println("Account Details after deposit:" + bankingServices.getAccountDetails(accNo));
					} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
						e.printStackTrace();
					}
					System.out.println();
					break;
				case 3:
					
					System.out.println("************FUND TRANSFER**********");
					System.out.println("Enter account no from where to withdraw");
					accNoFrom = sc.nextLong();
					System.out.println("Enter PIN number");
					pinNo = sc.nextInt();
					System.out.println("Enter account no where to deposit");
					accNoTo = sc.nextLong();
					System.out.println("Enter transfer amount");
					amt = sc.nextFloat();
					try {
						System.out.println(
								"Fund transfer status: " + bankingServices.fundTransfer(accNoTo, accNoFrom, amt, pinNo));
						System.out.println(
								"Account details after fund transfer: (to) \n" + bankingServices.getAccountDetails(accNoTo)
								+ "\n" + "\n(from)\n " + bankingServices.getAccountDetails(accNoFrom));
					} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
						e.printStackTrace();
					}
					break;
				case 4:
					System.exit(-1);
				default : 
					System.out.println("Invalid Input");
				}
			}

		  }
	}
